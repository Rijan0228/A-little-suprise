A LITTLE SURPRISE — UPDATED GITHUB PAGES FILES

Upload these to the ROOT of your existing GitHub repository:
- index.html
- style.css
- script.js
- assets/ (contains your 3 original photos and cropped moon photo)
- fireflies.mp3 (your own MP3 file; place it in the repository ROOT)

MUSIC
The player tries these names/locations:
- fireflies.mp3
- Fireflies.mp3
- assets/fireflies.mp3
- assets/Fireflies.mp3
For the most reliable setup, rename the song to exactly fireflies.mp3 and put it beside index.html.
Tap the music button once to start playback; mobile browsers require a user tap.

PASSWORD
1234

PHOTOS
The assets/photo1.jpg, photo2.jpg and photo3.jpg are the original photos already supplied. Replace them only if you want to update the pictures.

MOON
assets/birthday-moon.jpg is cropped from the screenshot to remove the phone status bar, website header, thumbnails and bottom navigation while preserving the dark moon image.

NOTES
- The video section/player and all video JavaScript were removed.
- The final moon screen keeps its dark original-style background; other sections use pink backgrounds.
- The countdown uses a bold sans-serif numeral so 1 is not mistaken for i.
- The wish jar uses a transparent glass effect and reveals four notes before unlocking the letter.
- This code does not call localStorage.clear() or remove saved browser data.
- The source package available to update did not contain the newer Future Wishes editor/viewer section. Existing browser localStorage is not cleared, but the exact Future Wishes screen cannot be restored from this older source snapshot alone.
